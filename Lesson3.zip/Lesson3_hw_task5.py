#5. В массиве найти максимальный отрицательный элемент. Вывести на экран его значение и позицию в массиве.
# Примечание к задаче: пожалуйста не путайте «минимальный» и «максимальный отрицательный». Это два абсолютно разных значения.
from random import random
N = 15
m = []
for i in range(N):
        m.append(int(random() * 100) - 50)
print(m)
i = 0
index = -1
while i < N:
        if m[i] < 0 and index == -1:
                index = i
        elif m[i] < 0 and m[i] > m[index]:
                index = i
        i += 1
print(index+1,':', m[index])

