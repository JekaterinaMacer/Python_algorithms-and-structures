#3. В массиве случайных целых чисел поменять местами минимальный и максимальный элементы.
from random import random
N = 20
m = [0]*N
for i in range(N):
    m[i] = int(random()*100)
    print(m[i],end=' ')
print()
mn = 0
mx = 0
for i in range(N):
    if m[i] < m[mn]:
        mn = i
    elif m[i] > m[mx]:
        mx = i
print('m[%d]=%d m[%d]=%d' % (mn+1, m[mn], mx+1, m[mx]))
b = m[mn]
m[mn] = m[mx]
m[mx] = b
for i in range(20):
    print(m[i],end=' ')
print()

